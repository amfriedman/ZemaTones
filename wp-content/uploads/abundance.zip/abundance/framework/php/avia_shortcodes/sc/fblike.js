scnShortcodeMeta = {
    attributes: [{
        label: "Style",
        id: "style",
        help: "Values: standard, button (default: standard).<p>Note: Depending on how fast the Facebook API is today, the preview could take a few moments to load.</p>"
    }],
    defaultContent: "",
    shortcode: "fblike"
};