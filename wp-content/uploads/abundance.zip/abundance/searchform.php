<form action="<?php echo home_url( '/' ); ?>" id="searchform" method="get">
	<div>
		<input type="submit" value="" id="searchsubmit" class="button"/>
		<input type="text" id="s" name="s" value="search site"/>
	</div>
</form><!-- end searchform-->